Dashboards for Lightbend Telemetry, using Cinnamon with a Prometheus data source.

See the [Cinnamon documentation][docs] for installing and configuring telemetry.

[docs]: https://developer.lightbend.com/docs/cinnamon/latest/home.html
